from replit import clear
#HINT: You can call clear() to clear the output in the console.
from art import logo
print(logo)
apostadores = {}
def bet(nome, aposta):
 apostadores[nome] = aposta


continua= True
while continua:
  n=input("qual seu nome? \n")
  a=int(input("quanto apostar? \n"))

  bet(nome = n, aposta = a)
  
  c = input("mais apostadoes? \n'sim' ou 'nao'\n ")
  if c == "nao":
    continua= False
  elif c == "sim":
    clear()
  
ganhador = ""
bet_a = 0
for i in apostadores:
  
  maior_bet = apostadores[i]
  
  if maior_bet > bet_a :
    bet_a = maior_bet
    ganhador = i
  

print(f"o ganhador foi {ganhador} com a aposta de {bet_a}")
