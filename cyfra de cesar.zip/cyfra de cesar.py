alfabeto = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']

def caesar(t, s, c):
  texto_F = ""
  if c == "decodificar":
    s *= -1
  for i in t:
 
    if i in alfabeto:
      posicao = alfabeto.index(i)
      n_posicao = posicao + s
      texto_F += alfabeto[n_posicao]
    else:
      texto_F += i
  print(f"aqui esta {c} resultado: {texto_F}")


from art import logo
print(logo)

finalizar = False

while not finalizar:

  direcao = input("digite 'codificar' para codificar a mensagem, digite 'decodificar' para decodificar a mensagem:\n")
  texto = input("digite a mensagem:\n").lower()
  pular = int(input("qual a quantidade de casas:\n"))
 
  pular = pular % 26

  caesar(t=texto, s=pular, c=direcao)

  restart = input("digite 'sim' se voce deseja continuar ou 'nao' se deseja parar .\n")
  if restart == "nao":
    finalizar = True
    print("thau")
    


